package popBands;

class UserLikes
{
    int[] myBands = new int[50]; 
}
